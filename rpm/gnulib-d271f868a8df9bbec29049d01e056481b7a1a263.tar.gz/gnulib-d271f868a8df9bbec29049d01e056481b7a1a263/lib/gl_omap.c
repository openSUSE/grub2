#include <config.h>
#define GL_OMAP_INLINE _GL_EXTERN_INLINE
#include "gl_omap.h"
